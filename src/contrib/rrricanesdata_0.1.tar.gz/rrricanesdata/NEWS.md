rrricanesdata 0.1 (2018-01-01)
==================================

### NEW FEATURES

* Includes all data through 2017 season.

### MINOR IMPROVEMENTS

* NA

### BUG FIXES

* NA

### DEPRECATED AND DEFUNCT

* NA

rrricanesdata 0.0.1.6 (2017-12-09)
==================================

### NEW FEATURES

* Datasets updated through 2017-12-08

### MINOR IMPROVEMENTS

* NA

### BUG FIXES

* NA

### DEPRECATED AND DEFUNCT

* NA

rrricanesdata 0.0.1.5 (2017-10-05)
==================================

### NEW FEATURES

* Datasets updated through 2017-09-30

### MINOR IMPROVEMENTS

* NA

### BUG FIXES

* NA

### DEPRECATED AND DEFUNCT

* NA

rrricanesdata 0.0.1.3 (2017-08-05)
==================================

### NEW FEATURES

* Datasets updated through 2017-07-31

### MINOR IMPROVEMENTS

* NA

### BUG FIXES

* NA

### DEPRECATED AND DEFUNCT

* NA

rrricanesdata 0.0.1 (2017-07-16)
==================================

### NEW FEATURES

* All product and tidied datasets, both basins, added; covers 1998 to July 13, 2017.

### MINOR IMPROVEMENTS

* NA

### BUG FIXES

* NA

### DEPRECATED AND DEFUNCT

* NA
